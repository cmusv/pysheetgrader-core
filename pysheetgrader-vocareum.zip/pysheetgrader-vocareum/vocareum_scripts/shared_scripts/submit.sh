#!/bin/bash

cp $LIB/pysheetgrader-vocareum/vocareum_scripts/shared_scripts/lib_submit.sh lib_submit.sh
source lib_submit.sh
